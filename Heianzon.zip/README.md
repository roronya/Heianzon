# Heianzon
chrome extension for 平安堂 like Libron

[https://chrome.google.com/webstore/detail/heianzon/aobkiihmmmalfambojkpacinnpjmopam?hl=ja](https://chrome.google.com/webstore/detail/heianzon/aobkiihmmmalfambojkpacinnpjmopam?hl=ja)